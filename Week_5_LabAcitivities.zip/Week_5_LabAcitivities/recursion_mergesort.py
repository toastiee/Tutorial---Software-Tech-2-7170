import random
import timeit


# RECURSION
# At its core, recursion involves solving a problem 
# by breaking it down into smaller, more manageable instances of the same problem. 

# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case

def sum_of_natural_numbers_iterative(n):
    total = 0
    for i in range(1, n + 1):
        total += i
    return total # Iterative version for comparison

# Example usage:
result = sum_of_natural_numbers(5)  # Calculates 1 + 2 + 3 + 4 + 5
print(f"The sum of the first 5 natural numbers is {result}")

result = sum_of_natural_numbers_iterative(5)  # Calculates 1 + 2 + 3 + 4 + 5
print(f"The sum of the first 5 natural numbers (iterative) is {result}")

# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

def fibonacci_iterative(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        a, b = 0, 1
        for _ in range(2, n + 1):
            a, b = b, a + b
        return b # Iterative version for comparison

# Example usage:
result = fibonacci(7)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
print(f"The 7th Fibonacci number is {result}")

result = fibonacci_iterative(7)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
print(f"The 7th Fibonacci number (iterative) is {result}")



# CHALLENGE: Use recursion to calculate the factorial.
def factorial(n):
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!
    
def factorial_iterative(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# Example usage:
num = 5
result = factorial(num)
print(f"The factorial of {num} is {result}")

result = factorial_iterative(num)
print(f"The factorial of {num} (iterative) is {result}")


# MINI-PROJECT: MERGE SORT
def merge_sort(array):
    if len(array) <= 1:
        return array
    else:
        left_split = array[:len(array)//2]
        right_split = array[len(array)//2:]
        left = merge_sort(left_split)
        right = merge_sort(right_split)        
        return merge(left, right)

        
def merge(left, right):
    merged = []
    left_pointer = 0
    right_pointer = 0
    merging = True

    while merging:
        left_element = left[left_pointer]
        right_element = right[right_pointer]

        if left_element < right_element:
            merged.append(left_element)
            left_pointer += 1
        elif right_element < left_element:
            merged.append(right_element)
            right_pointer += 1
        elif right_element == left_element:
            merged.append(right_element)
            merged.append(left_element)
            left_pointer += 1
            right_pointer += 1

        if left_pointer >= len(left):
            merged.extend(right[right_pointer:])
            merging = False
        elif right_pointer >= len(right):
            merged.extend(left[left_pointer:])
            merging = False

    return merged


# INSERTION SORT
def insertion_sort(arr):
    for i in range(1, len(arr)):
        current_element = arr[i]
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = current_element
    return arr


# Testing MERGE SORT with INSERTION SORT
large_random_list = [random.randint(1, 1000) for _ in range(100)]

insertion_time = timeit.timeit(lambda: insertion_sort(large_random_list[:]), number=10)
merge_time = timeit.timeit(lambda: merge_sort(large_random_list[:]), number=10)

print(f"Insertion Sort took: {insertion_time:.6f} seconds")
print(f"Merge Sort took: {merge_time:.6f} seconds")


# Merge sort test cases
l = [2, 6, 9, 5, 3, 4, 5, 6, 6, 7]
print(l)
print()
sorted_result = merge_sort(l)
print(sorted_result)

l = [1]
sorted_result = merge_sort(l)
print(sorted_result)

l = [random.randint(1, 1000) for n in range(10000)]
sorted_result = merge_sort(l)
print(sorted_result[:50])

n = 80
sum = n
while n > 0:
    n -= 1
    sum += n
print(sum)

# Test Merge Sort for different data sizes
print("\n" + "="*50 + "\n")
print("TESTING MERGE SORT FOR DIFFERENT DATA SIZES")
print("\n" + "="*50 + "\n") 

data_sizes = [10, 100, 500, 1000, 5000]

for size in data_sizes:
    test_data = [random.randint(1, 1000) for _ in range(size)]
    sorted_data = merge_sort(test_data[:])

    is_correct = sorted_data == sorted(test_data) 
    
    print(f"\nData size: {size}")
    print(f"  Input (first 10):  {test_data[:10]}")
    print(f"  Output (first 10): {sorted_data[:10]}")
    print(f"  Correctly sorted:  {is_correct}")

# Test Insertion Sort for different data sizes
print("\n" + "="*50 + "\n")
print("TESTING INSERTION SORT FOR DIFFERENT DATA SIZES")
print("\n" + "="*50 + "\n")

for size in data_sizes:
    test_data = [random.randint(1, 1000) for _ in range(size)]
    sorted_data = insertion_sort(test_data[:])  

    is_correct = sorted_data == sorted(test_data)
    
    print(f"\nData size: {size}")
    print(f"  Input (first 10):  {test_data[:10]}")
    print(f"  Output (first 10): {sorted_data[:10]}")
    print(f"  Correctly sorted:  {is_correct}")
    
# Benchmarking Merge Sort vs Insertion Sort (timeit)
print("\n" + "="*50 + "\n")
print("BENCHMARKING MERGE SORT VS INSERTION SORT")
print("\n" + "="*50 + "\n")

benchmark_sizes = [10, 100, 500, 1000, 5000]
REPEATS = 20

print(f"{'Size':<8} {'Merge Sort (s)':<20} {'Insertion Sort (s)':<22} {'Faster?'}")
print("-" * 65)

for size in benchmark_sizes:
    test_data = [random.randint(1, 1000) for _ in range(size)]
    
    merge_time = timeit.timeit(
        lambda: merge_sort(test_data[:]), 
        number=REPEATS
    )
    
    insertion_time = timeit.timeit(
        lambda: insertion_sort(test_data[:]), 
        number=REPEATS
    )
    
    faster = "Merge Sort" if merge_time < insertion_time else "Insertion Sort"
    ratio = max(merge_time, insertion_time) / min(merge_time, insertion_time)
    
    print(f"{size:<8} {merge_time:<20.6f} {insertion_time:<22.6f} {faster} ({ratio:.1f}x)")

# Task 1.3 COMPARING ITERATIVE VS RECURSIVE FOR DIFFERENT DATA SIZES
print("\n" + "="*50 + "\n")
print("COMPARING ITERATIVE VS RECURSIVE FOR DIFFERENT DATA SIZES")
print("\n" + "="*50 + "\n")

data_sizes = [10, 50, 100, 200, 500]

# Sum of Natural Numbers
print("\nSum of Natural Numbers:")
print(f"{'N':<10} {'Recursive Time (s)': <25} {'Iterative Time (s)': <25}")
for size in data_sizes:
    recursive_time = timeit.timeit(lambda: sum_of_natural_numbers(size), number=1000)
    iterative_time = timeit.timeit(lambda: sum_of_natural_numbers_iterative(size), number=1000)
    print(f"{size:<10} {recursive_time:<25.6f} {iterative_time:<25.6f}")

# Fibonacci Sequence
print("\nFibonacci Sequence:")
print(f"{'N':<10} {'Recursive Time (s)': <25} {'Iterative Time (s)': <25}")
fib_sizes = [5,10,15,20,25]
for size in fib_sizes:
    recursive_time = timeit.timeit(lambda: fibonacci(size), number=100)
    iterative_time = timeit.timeit(lambda: fibonacci_iterative(size), number=100)
    print(f"{size:<10} {recursive_time:<25.6f} {iterative_time:<25.6f}")

# Factorial
print("\nFactorial:")
print(f"{'N':<10} {'Recursive Time (s)': <25} {'Iterative Time (s)': <25}")
factorial_sizes = [5,10,15,20,25]
for size in factorial_sizes:
    recursive_time = timeit.timeit(lambda: factorial(size), number=1000)
    iterative_time = timeit.timeit(lambda: factorial_iterative(size), number=1000)
    print(f"{size:<10} {recursive_time:<25.6f} {iterative_time:<25.6f}")