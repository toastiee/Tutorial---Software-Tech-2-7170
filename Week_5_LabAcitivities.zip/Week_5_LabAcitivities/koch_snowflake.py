from tkinter import * # Import tkinter
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()  # Create a window
        window.title("Koch Snowflake")  # Set the title of the window

        self.width = 500
        self.height = 500
        self.canvas = Canvas(window, width=self.width, height=self.height, bg="white")
        self.canvas.pack()

        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window)  # Create and add a frame to window
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Koch Snowflake", command=self.display).pack(side=LEFT)
        window.mainloop()  # Create an event loop

    def display(self):
        self.canvas.delete("line")

        # Define an equilateral triangle centered in the canvas
        cx = self.width / 2
        cy = self.height / 2
        size = 350  # Side length of the initial triangle

        # Calculate the three vertices of the equilateral triangle
        # pointing upward
        p1 = [cx, cy - size * math.sqrt(3) / 3]               # Top vertex
        p2 = [cx - size / 2, cy + size * math.sqrt(3) / 6]    # Bottom-left vertex
        p3 = [cx + size / 2, cy + size * math.sqrt(3) / 6]    # Bottom-right vertex

        order = int(self.order.get())

        # Draw all three sides of the snowflake
        self.drawKochSide(order, p1, p2)
        self.drawKochSide(order, p2, p3)
        self.drawKochSide(order, p3, p1)

    def drawKochSide(self, order, p1, p2):
        """
        Recursively draws one side of the Koch snowflake.
        Each side is divided into 4 segments:
          p1 -> pA -> pPeak -> pB -> p2
        where a triangle bump is drawn outward on the middle third.
        """
        if order == 0:
            # Base case: draw a straight line between the two points
            self.drawLine(p1, p2)
        else:
            # Divide the segment into thirds
            pA = self.thirdPoint(p1, p2)     # 1/3 point
            pB = self.thirdPoint(p2, p1)     # 2/3 point (1/3 from p2)

            # Calculate the peak of the equilateral triangle on the middle third
            pPeak = self.kochPeak(pA, pB)

            # Recursively draw the 4 sub-segments
            self.drawKochSide(order - 1, p1, pA)
            self.drawKochSide(order - 1, pA, pPeak)
            self.drawKochSide(order - 1, pPeak, pB)
            self.drawKochSide(order - 1, pB, p2)

    def thirdPoint(self, p1, p2):
        """Returns the point 1/3 of the way from p1 to p2."""
        return [
            p1[0] + (p2[0] - p1[0]) / 3,
            p1[1] + (p2[1] - p1[1]) / 3
        ]

    def kochPeak(self, pA, pB):
        """
        Returns the apex of an equilateral triangle built outward
        on the segment from pA to pB.
        """
        # Midpoint of pA -> pB
        mx = (pA[0] + pB[0]) / 2
        my = (pA[1] + pB[1]) / 2

        # Perpendicular direction (rotated 90 degrees), scaled for equilateral triangle
        dx = pB[0] - pA[0]
        dy = pB[1] - pA[1]

        # Height of equilateral triangle = (sqrt(3)/2) * side_length
        # Outward perpendicular: (-dy, dx) normalised then scaled
        height = math.sqrt(3) / 2

        px = mx - dy * height
        py = my + dx * height

        return [px, py]

    def drawLine(self, p1, p2):
        self.canvas.create_line(
            p1[0], p1[1], p2[0], p2[1], tags="line", fill="blue")

    def midpoint(self, p1, p2):
        """Return the midpoint between two points (kept for reference)."""
        p = 2 * [0]
        p[0] = (p1[0] + p2[0]) / 2
        p[1] = (p1[1] + p2[1]) / 2
        return p

KochSnowflake()  # Create GUIs