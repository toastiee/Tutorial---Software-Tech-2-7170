moveCount = 0  # Global variable to track number of moves

def main():
    global moveCount
    n = eval(input("Enter the number of disks: "))
    moveCount = 0  # Reset counter for each run

    # Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print("The number of moves is", moveCount)

# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower
def moveDisks(n, fromTower, toTower, auxTower):
    global moveCount
    if n == 1:  # Stopping condition
        print("Move disk", n, "from", fromTower, "to", toTower)
        moveCount += 1  # Increment for every move
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        moveCount += 1  # Increment for every move
        moveDisks(n - 1, auxTower, toTower, fromTower)

main()  # Call the main function