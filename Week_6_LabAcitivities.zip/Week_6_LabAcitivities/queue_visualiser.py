import tkinter as tk
from tkinter import messagebox
from collections import deque

NODE_WIDTH = 80
NODE_HEIGHT = 40
HORIZONTAL_GAP = 10
CANVAS_WIDTH = 600
CANVAS_HEIGHT = 200

class Queue:
    """Queue data structure using deque (FIFO - First In, First Out)."""
    def __init__(self):
        self._data = deque()

    def enqueue(self, value):
        """Add an element to the rear of the queue."""
        self._data.append(value)

    def dequeue(self):
        """Remove and return the front element of the queue."""
        if self.is_empty():
            raise IndexError("Dequeue from an empty queue")
        return self._data.popleft()

    def peek(self):
        """Return the front element without removing it."""
        if self.is_empty():
            raise IndexError("Peek from an empty queue")
        return self._data[0]

    def is_empty(self):
        return len(self._data) == 0

    def size(self):
        return len(self._data)

    def __iter__(self):
        return iter(self._data)


class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer (FIFO)")
        self.root.configure(bg="#f0f4f8")

        self.queue = Queue()

        # Title
        title_label = tk.Label(
            root,
            text="Queue Visualizer — FIFO (First In, First Out)",
            font=("Courier", 14, "bold"),
            bg="#1a1a2e", fg="#e0e0ff",
            padx=10, pady=8
        )
        title_label.pack(fill=tk.X)

        # Canvas for drawing
        canvas_frame = tk.Frame(root, bg="#f0f4f8")
        canvas_frame.pack(pady=15, padx=20)

        # Front/Rear labels
        label_frame = tk.Frame(canvas_frame, bg="#f0f4f8")
        label_frame.pack()

        self.front_label = tk.Label(label_frame, text="FRONT →", font=("Courier", 11, "bold"),
                                    bg="#f0f4f8", fg="#e63946")
        self.front_label.pack(side=tk.LEFT, padx=5)

        self.rear_label = tk.Label(label_frame, text="← REAR", font=("Courier", 11, "bold"),
                                   bg="#f0f4f8", fg="#2a9d8f")
        self.rear_label.pack(side=tk.RIGHT, padx=5)

        self.canvas = tk.Canvas(canvas_frame, width=CANVAS_WIDTH, height=CANVAS_HEIGHT,
                                bg="#16213e", highlightthickness=2,
                                highlightbackground="#0f3460")
        self.canvas.pack(pady=5)

        # Arrow labels below canvas
        arrow_frame = tk.Frame(root, bg="#f0f4f8")
        arrow_frame.pack()
        tk.Label(arrow_frame, text="⬅  Dequeue (remove from FRONT)",
                 font=("Courier", 10), bg="#f0f4f8", fg="#e63946").pack(side=tk.LEFT, padx=20)
        tk.Label(arrow_frame, text="Enqueue (add to REAR)  ➡",
                 font=("Courier", 10), bg="#f0f4f8", fg="#2a9d8f").pack(side=tk.RIGHT, padx=20)

        # Controls
        control_frame = tk.Frame(root, bg="#f0f4f8")
        control_frame.pack(pady=10)

        tk.Label(control_frame, text="Value:", font=("Courier", 12),
                 bg="#f0f4f8").grid(row=0, column=0, padx=5)
        self.entry = tk.Entry(control_frame, width=10, font=("Courier", 12))
        self.entry.grid(row=0, column=1, padx=5)

        enqueue_btn = tk.Button(
            control_frame, text="Enqueue (Push)", command=self.enqueue_value,
            font=("Courier", 11, "bold"), bg="#2a9d8f", fg="white",
            relief=tk.FLAT, padx=10, pady=4, cursor="hand2"
        )
        enqueue_btn.grid(row=0, column=2, padx=8)

        dequeue_btn = tk.Button(
            control_frame, text="Dequeue (Pop)", command=self.dequeue_value,
            font=("Courier", 11, "bold"), bg="#e63946", fg="white",
            relief=tk.FLAT, padx=10, pady=4, cursor="hand2"
        )
        dequeue_btn.grid(row=0, column=3, padx=8)

        # Status
        self.status_label = tk.Label(root, text="Queue is empty. Enqueue a value to begin.",
                                     fg="#0f3460", font=("Courier", 11), bg="#f0f4f8")
        self.status_label.pack(pady=6)

        # Size info
        self.size_label = tk.Label(root, text="Queue size: 0",
                                   font=("Courier", 10), bg="#f0f4f8", fg="#555")
        self.size_label.pack()

        self.draw_queue()

    def draw_queue(self):
        self.canvas.delete("all")
        items = list(self.queue)
        n = len(items)

        if n == 0:
            self.canvas.create_text(
                CANVAS_WIDTH // 2, CANVAS_HEIGHT // 2,
                text="[ empty queue ]",
                font=("Courier", 14), fill="#556688"
            )
            self.front_label.config(text="FRONT →")
            self.rear_label.config(text="← REAR")
            self.size_label.config(text="Queue size: 0")
            return

        total_width = n * NODE_WIDTH + (n - 1) * HORIZONTAL_GAP
        start_x = (CANVAS_WIDTH - total_width) // 2
        y = (CANVAS_HEIGHT - NODE_HEIGHT) // 2

        for i, val in enumerate(items):
            x = start_x + i * (NODE_WIDTH + HORIZONTAL_GAP)

            # Color: front = red tint, rear = green tint, middle = blue
            if i == 0:
                fill_color = "#ff6b6b"
                outline_color = "#e63946"
            elif i == n - 1:
                fill_color = "#52b788"
                outline_color = "#2a9d8f"
            else:
                fill_color = "#4895ef"
                outline_color = "#4361ee"

            self.canvas.create_rectangle(
                x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
                fill=fill_color, outline=outline_color, width=2
            )
            self.canvas.create_text(
                x + NODE_WIDTH // 2, y + NODE_HEIGHT // 2,
                text=str(val), font=("Courier", 15, "bold"), fill="white"
            )

            # Draw arrow between nodes
            if i < n - 1:
                ax = x + NODE_WIDTH + 1
                ay = y + NODE_HEIGHT // 2
                self.canvas.create_line(
                    ax, ay, ax + HORIZONTAL_GAP - 1, ay,
                    arrow=tk.LAST, fill="#aaaacc", width=2
                )

            # Front/Rear labels under nodes
            if i == 0:
                self.canvas.create_text(
                    x + NODE_WIDTH // 2, y + NODE_HEIGHT + 14,
                    text="FRONT", font=("Courier", 9, "bold"), fill="#e63946"
                )
            if i == n - 1:
                self.canvas.create_text(
                    x + NODE_WIDTH // 2, y + NODE_HEIGHT + 14,
                    text="REAR", font=("Courier", 9, "bold"), fill="#2a9d8f"
                )

        self.size_label.config(text=f"Queue size: {n}")

    def enqueue_value(self):
        try:
            val = int(self.entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value.")
            return
        self.queue.enqueue(val)
        self.entry.delete(0, tk.END)
        self.status_label.config(
            text=f"Enqueued {val} → added to REAR of queue",
            fg="#2a9d8f"
        )
        self.draw_queue()

    def dequeue_value(self):
        if self.queue.is_empty():
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot dequeue.")
            return
        val = self.queue.dequeue()
        self.status_label.config(
            text=f"Dequeued {val} ← removed from FRONT of queue",
            fg="#e63946"
        )
        self.draw_queue()


if __name__ == "__main__":
    root = tk.Tk()
    root.resizable(False, False)
    app = QueueVisualizer(root)

    # Example test cases (uncomment to pre-load):
    # for v in [10, 20, 30, 40, 50]:
    #     app.queue.enqueue(v)
    # app.draw_queue()

    root.mainloop()